# PrepMate – Academic Project Submission Report

## Student & Course Details
- **Student Name**: [Enter Your Name]
- **Roll / Registration Number**: [Enter Your Roll Number]
- **Course**: Placement Training & Web Technologies
- **Academic Year**: 2026

---

## 🚀 Projects Included

### 1. Task 1: PrepMate – Student Placement Preparation Portal
- **Technology**: HTML5, CSS3, Vanilla JavaScript, LocalStorage
- **Folder**: `Task-1_PrepMate-Website/`
- **Pages**:
  - `index.html`: Professional landing page with quick stats, core features, and workflow guide.
  - `aptitude.html`: Interactive quiz arena (Quant, Logical, Verbal) with scoring and detailed explanations.
  - `dsa.html`: Filterable coding challenges with complexity breakdowns and problem modal.
  - `companies.html`: Hiring round breakdowns and skill requirements for 10 top recruiters.
  - `resources.html`: Concept cheatsheets and essential interview questions for Core CS & Programming.
  - `dashboard.html`: Student analytics KPI cards, progress bars, and live activity log.

### 2. Task 2: PrepMate – Placement Focus Assistant (Chrome Extension)
- **Technology**: Chrome Extension Manifest V3, Chrome Storage API, Notifications API, Alarms API, Content Scripts, Service Worker
- **Folder**: `Task-2_PrepMate-ChromeExtension/`
- **Features**:
  - Pomodoro Study Timer (25m/50m focus, 5m/10m break) with background persistence.
  - Desktop notifications on session and break completions.
  - Deep focus mode live stopwatch tracker.
  - Webpage content analyzer estimating reading time and word counts.
  - Quick placement notes management.
  - Dark / Light theme switcher.

---

## 📸 Screenshots Directory (`screenshots/`)
1. `01_home_page.png` – Web Portal Landing Page
2. `02_aptitude_quiz.png` – Interactive Aptitude Arena
3. `03_dsa_practice.png` – DSA Practice Hub & Filters
4. `04_companies_guide.png` – Top Recruiter Preparation Guides
5. `05_resources_hub.png` – Core CS & Language Roadmaps
6. `06_dashboard_progress.png` – Student Analytics Dashboard
7. `07_chrome_extension_popup.png` – Chrome Extension Focus Assistant

---

## 🤖 Generative AI Tool & Assistance
- **AI Tool**: Antigravity (Google DeepMind)
- **Assistance**:
  - Architecture and manifest design
  - Modular UI/UX styling with dark/light themes
  - Quiz and timer state machine logic
  - Background alarm scheduling & DOM TreeWalker content scripts
  - Automated testing and responsive verification

---

## 📝 Changes Made by Student
- [x] Verified all mathematical and logical aptitude explanations.
- [x] Tested responsive views on desktop, tablet, and mobile browsers.
- [x] Tested background timer persistence and notification delivery on Chrome.
- [x] Formatted and packaged the final assignment for Classroom submission.
